#include <stdio.h>

int x[6] = {-1, -1, -1, -1, -1, -1};
int n = 6;
void printSolution()
{
    for (int k = 0; k < n; k++)
        printf("% d", x[k]);
    printf("\n");
}
int TRY(int k)
{
    for (int v = 0; v <= 1; v++)
    {
        x[k] = v;
        if (k == n - 1)
            printSolution();
        else
            TRY(k + 1);
    }
}
int main()
{
    TRY(0);
}