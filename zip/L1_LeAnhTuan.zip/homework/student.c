#include <stdio.h>
#define MAX_ELEMENT 6

typedef struct
{
    int id;
    char mssv[20];
    char name[20];
    char sdt[20];
    int diem;
} student;

int main(void)
{
    FILE *f, *p;
    student st[MAX_ELEMENT];
    int i = 0;
    if ((f = fopen("student.txt", "r")) == NULL)
    {
        printf("Can not open %s.\n",
               "product.txt");
        return 1;
    }
    else
    {
        //doc file student.txt
        int i = 0;
        while (fscanf(f, "%d%s%s%s", &st[i].id, st[i].mssv, st[i].name, &st[i].sdt) != EOF)
        {
            printf("%-6d%-24s%-24s%-24s\n", st[i].id, st[i].mssv, st[i].name, &st[i].sdt);
            i++;
        }

        //in ra banhdiem.txt
        p = fopen("bangdiem.txt", "w");
        fprintf(p, "%-6s%-24s%-24s%-24s%-12s\n", "ID", "MSSV", "NAME", "SDT", "Diem");
        int sl = i;
        for (int i = 0; i < sl; ++i)
        {
            printf("\nNhap diem cho hoc sinh %d: ", st[i].id);
            scanf("%d", &st[i].diem);
            fprintf(p, "%-6d%-24s%-24s%-24s%-12d\n", st[i].id, st[i].mssv, st[i].name, st[i].sdt, st[i].diem);
        }
    }
    fclose(f);
    fclose(p);
    return 0;
}