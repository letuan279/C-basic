for (int j1 = 0; j1 <= j - 1; j1++)
    //     if (x[3 * I + i][3 * J + j1] == v)
    //         return 0;